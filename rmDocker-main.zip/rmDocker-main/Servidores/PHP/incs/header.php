<?php require 'versionLogs.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Audios del Pesebre Viviente</title>
</head>
<body>
<header class="header">
    <h1>Audios del Pesebre Viviente</h1>
    <h2>Bº Yacampiz - 2024</h2>
    <p>Versión: <?= htmlspecialchars($latestVersion) ?> | Asociación CAMPS</p>
</header>
