<footer class="footer">
    <p>Propiedad de Asociación CAMPS | Inspirado en la fe y la música</p>
</footer>
</body>
</html>
