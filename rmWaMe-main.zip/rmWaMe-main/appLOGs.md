appLOGs.md

# v0.2: 
	- INDEX: Personalizo, traduzco y optimizo textos.
	- APP: Agrega appLOGs.md
	- INDEX: Indento el código.
# v0.1: 
	- Inicio del proyecto.
