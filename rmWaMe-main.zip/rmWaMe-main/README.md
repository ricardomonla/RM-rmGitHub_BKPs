# rmWaMe
rmWaMe es una páginba que genera el script url para enviar un mensaje por la API de WhatsApp.
