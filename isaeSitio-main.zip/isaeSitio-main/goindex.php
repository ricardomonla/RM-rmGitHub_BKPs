<?php
	
	$newURL = '../';
	// $newURL = 'http://www.frlr.utn.edu.ar';
	
	header('Location: '.$newURL);

	die();

?>
