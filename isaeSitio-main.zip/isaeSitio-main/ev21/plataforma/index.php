<?php
	
	$newURL = 'https://www.santillanaconnect.com/Account/Login/?wtrealm=http%3a%2f%2flms30.santillanacompartir.com%2flogin%2fcompartir%2f&wreply=https%3a%2f%2flms30.santillanacompartir.com%2flogin%2fsso%2floginconnect';
	// $newURL = 'http://www.frlr.utn.edu.ar';
	
	header('Location: '.$newURL);

	die();

?>
