<?php
	
	$newURL = 'https://www.youtube.com/channel/UCI3HmS5gkPd8d7vnPJKcY_A';
	// $newURL = 'http://www.frlr.utn.edu.ar';
	
	header('Location: '.$newURL);

	die();

?>
