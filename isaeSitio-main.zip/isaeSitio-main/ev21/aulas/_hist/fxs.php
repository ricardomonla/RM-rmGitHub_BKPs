<?php 
	include_once 'bdAulas.php';
	include_once 'bdCals.php';

?>