<?php
	
	$newURL = 'https://docs.google.com/document/d/1gbDEs-QOZbF9e5kOGeW0RPvPPcpDnzNiaPX3yY_LnFE/edit?usp=sharing';
	// $newURL = 'http://www.frlr.utn.edu.ar';
	
	header('Location: '.$newURL);

	die();

?>
