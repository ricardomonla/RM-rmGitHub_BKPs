TSPUTNLR_13_IO_MetodoSimplex
============================
Tecnicatura Superior En Programación
UTN Facultad Regional La Rioja
Materia: Investigación Operativa
Tema: Metodo Simplex

El Objetivo de este trabajo es el de dasarrollar un sistema 
que calcule las variables usando el metodo de calculo simplex. 


Tec. MONLA Ricardo
rmonla@gmail.com
