$(function() {
	$('#featured_wrap').tabs({
		fx: {
			opacity: 'show'
		}
	}).tabs('rotate', 8000);
});