<?php  
	/*<®> Inicializo Variables <®>*/
		
	/*<®> fxsBD <®>*/
		include_once 'fxsBD.php';

?>
