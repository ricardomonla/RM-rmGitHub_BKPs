<?php
require("validar.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0014)about:internet -->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>index_admin.gif</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--Fireworks CS3 Dreamweaver CS3 target.  Created Wed Sep 08 17:32:02 GMT-0600 2010-->
<script language="JavaScript1.2" type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

//-->
</script>
<script language="JavaScript1.2" type="text/javascript" src="mm_css_menu.js"></script>
<style type="text/css">
	@import url("./index_admin.css");
#FWTableContainer21604755 {
	text-align: center;
}
#FWTableContainer21604755 {
	text-align: center;
}
#centro {
	text-align: center;
}
.der {
	text-align: left;
}
</style>

</head>
<body bgcolor="#ffffff" onload="MM_preloadImages('img/index_admin_r3_c4_f2.gif');"><table width="500" border="0" align="center" cellspacing="0">
  <tr>
    <td><div id="FWTableContainer21604755">
<table border="0" cellpadding="0" cellspacing="0" width="800" align="center">
<!-- fwtable fwsrc="indes2.png" fwpage="index_admin" fwbase="index_admin.gif" fwstyle="Dreamweaver" fwdocid = "21604755" fwnested="0" -->
  <tr>
   <td><img src="img/spacer.gif" width="15" height="1" border="0" alt="" /></td>
   <td><img src="img/spacer.gif" width="148" height="1" border="0" alt="" /></td>
   <td><img src="img/spacer.gif" width="144" height="1" border="0" alt="" /></td>
   <td><img src="img/spacer.gif" width="96" height="1" border="0" alt="" /></td>
   <td><img src="img/spacer.gif" width="31" height="1" border="0" alt="" /></td>
   <td><img src="img/spacer.gif" width="131" height="1" border="0" alt="" /></td>
   <td><img src="img/spacer.gif" width="115" height="1" border="0" alt="" /></td>
   <td><img src="img/spacer.gif" width="105" height="1" border="0" alt="" /></td>
   <td><img src="img/spacer.gif" width="15" height="1" border="0" alt="" /></td>
   <td><img src="img/spacer.gif" width="1" height="1" border="0" alt="" /></td>
  </tr>

  <tr>
   <td colspan="9"><img name="index_admin_r1_c1" src="img/index_admin_r1_c1.gif" width="800" height="40" border="0" id="index_admin_r1_c1" alt="" /></td>
   <td><img src="img/spacer.gif" width="1" height="40" border="0" alt="" /></td>
  </tr>
  <tr>
   <td colspan="4"><img name="index_admin_r2_c1" src="img/index_admin_r2_c1.gif" width="403" height="71" border="0" id="index_admin_r2_c1" alt="" /></td>
   <td colspan="5"><img name="index_admin_r2_c5" src="img/index_admin_r2_c5.gif" width="397" height="71" border="0" id="index_admin_r2_c5" alt="" /></td>
   <td><img src="img/spacer.gif" width="1" height="71" border="0" alt="" /></td>
  </tr>
  <tr>
   <td colspan="2"><a href="javascript:;" onmouseout="MM_menuStartTimeout(1000);" onmouseover="MM_menuShowMenu('MMMenuContainer0908175643_0', 'MMMenu0908175643_0',15,30,'index_admin_r3_c1');"><img name="index_admin_r3_c1" src="img/index_admin_r3_c1.gif" width="163" height="30" border="0" id="index_admin_r3_c1" alt="" /></a></td>
   <td><a href="javascript:;" onmouseout="MM_menuStartTimeout(1000);" onmouseover="MM_menuShowMenu('MMMenuContainer0908181154_1', 'MMMenu0908181154_1',16,30,'index_admin_r3_c3');"><img name="index_admin_r3_c3" src="img/index_admin_r3_c3.gif" width="144" height="30" border="0" id="index_admin_r3_c3" alt="" /></a></td>
   <td colspan="2"><a href="javascript:;" onmouseout="MM_swapImgRestore();MM_menuStartTimeout(1000);" onmouseover="MM_menuShowMenu('MMMenuContainer0908181438_2', 'MMMenu0908181438_2',8,30,'index_admin_r3_c4');MM_swapImage('img/index_admin_r3_c4','','img/index_admin_r3_c4_f2.gif',1);"><img name="index_admin_r3_c4" src="img/index_admin_r3_c4.gif" width="127" height="30" border="0" id="index_admin_r3_c4" alt="" /></a></td>
<!--    <td><img name="index_admin_r3_c6" src="img/index_admin_r3_c6.gif" width="131" height="30" border="0" id="index_admin_r3_c6" alt="" /></td>
   <td><img name="index_admin_r3_c7" src="img/index_admin_r3_c7.gif" width="115" height="30" border="0" id="index_admin_r3_c7" alt="" /></td>
 -->   
 	 <td colspan="2"><a href="cerrar_sesion.php"><img name="index_admin_r3_c8" src="img/index_admin_r3_c8.gif" width="120" height="30" border="0" id="index_admin_r3_c8" alt="" /></a></td>
   <td><img src="img/spacer.gif" width="1" height="30" border="0" alt="" /></td>
  </tr>
  <tr>
   <td rowspan="2"><img name="index_admin_r4_c1" src="img/index_admin_r4_c1.gif" width="15" height="405" border="0" id="index_admin_r4_c1" alt="" /></td>
   <td colspan="7"        bgcolor="#009966" align="left"><font color="#FFFFFF" face="Comic Sans MS" size="+1">Usuario en Sesion: <?php echo $_SESSION["nombre_completo"]; ?></font></td>
   <td rowspan="2"><img name="index_admin_r4_c9" src="img/index_admin_r4_c9.gif" width="15" height="405" border="0" id="index_admin_r4_c9" alt="" /></td>
   <td><img src="img/spacer.gif" width="1" height="28" border="0" alt="" /></td>
  </tr>
  <tr>
   <td colspan="7"                               ><iframe name="fondito" width="770" height="377" frameborder="0" id="fondito"></iframe></td>
   <td><img src="img/spacer.gif" width="1" height="377" border="0" alt="" /></td>
  </tr>
  <tr>
   <td colspan="9"><img name="index_admin_r6_c1" src="img/index_admin_r6_c1.gif" width="800" height="54" border="0" id="index_admin_r6_c1" alt="" /></td>
   <td><img src="img/spacer.gif" width="1" height="54" border="0" alt="" /></td>
  </tr>
</table>
<div id="MMMenuContainer0908175643_0">
	<div id="MMMenu0908175643_0" onmouseout="MM_menuStartTimeout(1000);" onmouseover="MM_menuResetTimeout();">
		<a href="javascript:;" id="MMMenu0908175643_0_Item_0" class="MMMIFVStyleMMMenu0908175643_0" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0','1');">
			<span class="MMMenuItemSpanMMMenu0908175643_0">Periodo</span>
			<img src="img/arrows.gif" alt="" class="MMArrowStyleMMMenu0908175643_0" />
		</a>
		<a href="javascript:;" id="MMMenu0908175643_0_Item_1" class="MMMIVStyleMMMenu0908175643_0" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0','2');">
			<span class="MMMenuItemSpanMMMenu0908175643_0">Carreras</span>
			<img src="img/arrows.gif" alt="" class="MMArrowStyleMMMenu0908175643_0" />
		</a>
		<a href="javascript:;" id="MMMenu0908175643_0_Item_2" class="MMMIVStyleMMMenu0908175643_0" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0','3');">
			<span class="MMMenuItemSpanMMMenu0908175643_0">Grado</span>
			<img src="img/arrows.gif" alt="" class="MMArrowStyleMMMenu0908175643_0" />
		</a>
		<a href="javascript:;" id="MMMenu0908175643_0_Item_3" class="MMMIVStyleMMMenu0908175643_0" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0','4');">
			<span class="MMMenuItemSpanMMMenu0908175643_0">Secciones</span>
			<img src="img/arrows.gif" alt="" class="MMArrowStyleMMMenu0908175643_0" />
		</a>
		<a href="javascript:;" id="MMMenu0908175643_0_Item_4" class="MMMIVStyleMMMenu0908175643_0" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0','5');">
			<span class="MMMenuItemSpanMMMenu0908175643_0">Materia</span>
			<img src="img/arrows.gif" alt="" class="MMArrowStyleMMMenu0908175643_0" />
		</a>
		<a href="javascript:;" id="MMMenu0908175643_0_Item_5" class="MMMIVStyleMMMenu0908175643_0" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0','6');">
			<span class="MMMenuItemSpanMMMenu0908175643_0">Noticias</span>
			<img src="img/arrows.gif" alt="" class="MMArrowStyleMMMenu0908175643_0" />
		</a>
	</div>
	<div id="MMMenu0908175643_0_1" onmouseout="MM_menuStartTimeout(1000);" onmouseover="MM_menuResetTimeout();">
		<a href="agregar_periodo.php" target="fondito" id="MMMenu0908175643_0_1_Item_0" class="MMMIFVStyleMMMenu0908175643_0_1" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0_1');">
			Abrir&nbsp;Nuevo&nbsp;Periodo
		</a>
		<a href="ver_periodo.php" target="fondito" id="MMMenu0908175643_0_1_Item_1" class="MMMIVStyleMMMenu0908175643_0_1" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0_1');">
			Ver&nbsp;Periodos
		</a>
	</div>
	<div id="MMMenu0908175643_0_2" onmouseout="MM_menuStartTimeout(1000);" onmouseover="MM_menuResetTimeout();">
		<a href="ver_carrera.php" target="fondito" id="MMMenu0908175643_0_2_Item_0" class="MMMIFVStyleMMMenu0908175643_0_2" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0_2');">
			Ver&nbsp;Carrera
		</a>
		<a href="agregar_carrera.php" target="fondito" id="MMMenu0908175643_0_2_Item_1" class="MMMIVStyleMMMenu0908175643_0_2" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0_2');">
			Nueva&nbsp;Carrera
		</a>
	</div>
	<div id="MMMenu0908175643_0_3" onmouseout="MM_menuStartTimeout(1000);" onmouseover="MM_menuResetTimeout();">
		<a href="ver_grado.php" target="fondito" id="MMMenu0908175643_0_3_Item_0" class="MMMIFVStyleMMMenu0908175643_0_3" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0_3');">
			Ver&nbsp;Grados
		</a>
		<a href="agregar_grado.php" target="fondito" id="MMMenu0908175643_0_3_Item_1" class="MMMIVStyleMMMenu0908175643_0_3" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0_3');">
			Nuevo&nbsp;Grado
		</a>
	</div>
	<div id="MMMenu0908175643_0_4" onmouseout="MM_menuStartTimeout(1000);" onmouseover="MM_menuResetTimeout();">
		<a href="ver_seccion.php" target="fondito" id="MMMenu0908175643_0_4_Item_0" class="MMMIFVStyleMMMenu0908175643_0_4" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0_4');">
			Ver&nbsp;Seccion
		</a>
		<a href="agregar_seccion.php" target="fondito" id="MMMenu0908175643_0_4_Item_1" class="MMMIVStyleMMMenu0908175643_0_4" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0_4');">
			Nueva&nbsp;Seccion
		</a>
	</div>
	<div id="MMMenu0908175643_0_5" onmouseout="MM_menuStartTimeout(1000);" onmouseover="MM_menuResetTimeout();">
		<a href="ver_materias.php" target="fondito" id="MMMenu0908175643_0_5_Item_0" class="MMMIFVStyleMMMenu0908175643_0_5" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0_5');">
			Ver&nbsp;Materias
		</a>
		<a href="agregar_materia.php" target="fondito" id="MMMenu0908175643_0_5_Item_1" class="MMMIVStyleMMMenu0908175643_0_5" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0_5');">
			Nueva&nbsp;Materia
		</a>
	</div>
	<div id="MMMenu0908175643_0_6" onmouseout="MM_menuStartTimeout(1000);" onmouseover="MM_menuResetTimeout();">
		<a href="ver_noticia.php" target="fondito" id="MMMenu0908175643_0_6_Item_0" class="MMMIFVStyleMMMenu0908175643_0_6" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0_6');">
			Ver&nbsp;Noticias
		</a>
		<a href="agregar_noticia.php" target="fondito" id="MMMenu0908175643_0_6_Item_1" class="MMMIVStyleMMMenu0908175643_0_6" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0_6');">
			Nueva&nbsp;Noticia
		</a>
	</div>
</div>
<div id="MMMenuContainer0908181154_1">
	<div id="MMMenu0908181154_1" onmouseout="MM_menuStartTimeout(1000);" onmouseover="MM_menuResetTimeout();">
		<a href="javascript:;" id="MMMenu0908181154_1_Item_0" class="MMMIFVStyleMMMenu0908181154_1" onmouseover="MM_menuOverMenuItem('MMMenu0908181154_1','1');">
			<span class="MMMenuItemSpanMMMenu0908181154_1">Alumnos(as)</span>
			<img src="img/arrows.gif" alt="" class="MMArrowStyleMMMenu0908181154_1" />
		</a>
		<a href="javascript:;" id="MMMenu0908181154_1_Item_1" class="MMMIVStyleMMMenu0908181154_1" onmouseover="MM_menuOverMenuItem('MMMenu0908181154_1');">
			Responsable
		</a>
	</div>
	<div id="MMMenu0908181154_1_1" onmouseout="MM_menuStartTimeout(1000);" onmouseover="MM_menuResetTimeout();">
		<a href="ver_alumno.php" target="fondito" id="MMMenu0908181154_1_1_Item_0" class="MMMIFVStyleMMMenu0908181154_1_1" onmouseover="MM_menuOverMenuItem('MMMenu0908181154_1_1');">
			Ver&nbsp;Alumnos(as)
		</a>
		<a href="agregar_alumno.php" target="fondito" id="MMMenu0908181154_1_1_Item_1" class="MMMIVStyleMMMenu0908181154_1_1" onmouseover="MM_menuOverMenuItem('MMMenu0908181154_1_1');">
			Nuevo&nbsp;Alumno(as)
		</a>
	</div>
</div>
<div id="MMMenuContainer0908181438_2">
	<div id="MMMenu0908181438_2" onmouseout="MM_menuStartTimeout(1000);" onmouseover="MM_menuResetTimeout();">
		<a href="javascript:;" id="MMMenu0908181438_2_Item_0" class="MMMIFVStyleMMMenu0908181438_2" onmouseover="MM_menuOverMenuItem('MMMenu0908181438_2','1');">
			<span class="MMMenuItemSpanMMMenu0908181438_2">Docentes</span>
			<img src="img/arrows.gif" alt="" class="MMArrowStyleMMMenu0908181438_2" />
		</a>
	</div>
	<div id="MMMenu0908181438_2_1" onmouseout="MM_menuStartTimeout(1000);" onmouseover="MM_menuResetTimeout();">
		<a href="ver_docente.php" target="fondito" id="MMMenu0908181438_2_1_Item_0" class="MMMIFVStyleMMMenu0908181438_2_1" onmouseover="MM_menuOverMenuItem('MMMenu0908181438_2_1');">
			Ver&nbsp;Docentes
		</a>
		<a href="agregar_docente.php" target="fondito" id="MMMenu0908181438_2_1_Item_1" class="MMMIVStyleMMMenu0908181438_2_1" onmouseover="MM_menuOverMenuItem('MMMenu0908181438_2_1');">
			Nuevo&nbsp;Docente
		</a>
		<a href="javascript:;" target="fondito" id="MMMenu0908181438_2_1_Item_2" class="MMMIVStyleMMMenu0908181438_2_1" onmouseover="MM_menuOverMenuItem('MMMenu0908181438_2_1');">
			Dar&nbsp;de&nbsp;Baja&nbsp;a&nbsp;Docente
		</a>
		<a href="ver_materias2.php" target="fondito" id="MMMenu0908181438_2_1_Item_3" class="MMMIVStyleMMMenu0908181438_2_1" onmouseover="MM_menuOverMenuItem('MMMenu0908181438_2_1');">
			Agregar&nbsp;Materia&nbsp;a&nbsp;Docente
		</a>
	</div>
</div>
</div></td>
  </tr>
</table>
</body>
</html>