<title>.:: SISTEMA DE REGISTRO ACADEMICO ::.</title>
<!--Fireworks CS3 Dreamweaver CS3 target.  Created Sat Aug 28 07:30:34 GMT-0600 2010-->
<style type="text/css">
td img {display: block;}a {
	text-align: center;
}
a {
	text-align: center;
}
</style>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<body bgcolor="#ffffff">
<form id="form1" name="form1" method="post" action="index2.php">
  <table width="800" border="0" align="center" cellpadding="0" cellspacing="0">
    <!-- fwtable fwsrc="indesx.png" fwpage="index" fwbase="index.gif" fwstyle="Dreamweaver" fwdocid = "21604755" fwnested="0" -->
    <tr>
      <td><img src="spacer.gif" width="15" height="1" border="0" alt="" /></td>
      <td><img src="spacer.gif" width="388" height="1" border="0" alt="" /></td>
      <td><img src="spacer.gif" width="113" height="1" border="0" alt="" /></td>
      <td><img src="spacer.gif" width="30" height="1" border="0" alt="" /></td>
      <td><img src="spacer.gif" width="254" height="1" border="0" alt="" /></td>
      <td><img src="spacer.gif" width="1" height="1" border="0" alt="" /></td>
    </tr>
    <tr>
      <td colspan="5"><img name="index_r1_c1" src="index_r1_c1.gif" width="800" height="40" border="0" id="index_r1_c1" alt="" /></td>
      <td><img src="spacer.gif" width="1" height="40" border="0" alt="" /></td>
    </tr>
    <tr>
      <td colspan="2"><img name="index_r2_c1" src="index_r2_c1.gif" width="403" height="63" border="0" id="index_r2_c1" alt="" /></td>
      <td rowspan="2" colspan="3"><img name="index_r2_c3" src="index_r2_c3.gif" width="397" height="64" border="0" id="index_r2_c3" /></td>
      <td><img src="spacer.gif" width="1" height="63" border="0" alt="" /></td>
    </tr>
    <tr>
      <td rowspan="2" colspan="2"><img name="index_r3_c1" src="index_r3_c1.gif" width="403" height="13" border="0" id="index_r3_c1" alt="" /></td>
      <td><img src="spacer.gif" width="1" height="1" border="0" alt="" /></td>
    </tr>
    <tr>
      <td><img name="index_r4_c3" src="index_r4_c3.gif" width="113" height="12" border="0" id="index_r4_c3" alt="" /></td>
      <td rowspan="10"><img name="index_r4_c4" src="index_r4_c4.gif" width="30" height="449" border="0" id="index_r4_c4" alt="" /></td>
      <td><img name="index_r4_c5" src="index_r4_c5.gif" width="254" height="12" border="0" id="index_r4_c5" alt="" /></td>
      <td><img src="spacer.gif" width="1" height="12" border="0" alt="" /></td>
    </tr>
    <tr>
      <td rowspan="9"><img name="index_r5_c1" src="index_r5_c1.gif" width="15" height="437" border="0" id="index_r5_c1" alt="" /></td>
      <td rowspan="9" colspan="2"><iframe name="mostrar" height="437" width="501" frameborder="0" src="ver_noticia2.php"></iframe></td>
      <td><img name="index_r5_c5" src="index_r5_c5.gif" width="254" height="61" border="0" id="index_r5_c5" alt="" /></td>
      <td><img src="spacer.gif" width="1" height="61" border="0" alt="" /></td>
    </tr>
    <tr>
      <td><img name="index_r6_c5" src="index_r6_c5.gif" width="254" height="47" border="0" id="index_r6_c5" alt="" /></td>
      <td><img src="spacer.gif" width="1" height="47" border="0" alt="" /></td>
    </tr>
    <tr>
      <td><img name="index_r7_c5" src="index_r7_c5.gif" width="254" height="39" border="0" id="index_r7_c5" alt="" /></td>
      <td><img src="spacer.gif" width="1" height="39" border="0" alt="" /></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><span id="sprytextfield1">
      <label>
        <input type="text" name="usuario" id="usuario">
      </label>
      <span class="textfieldRequiredMsg">Se necesita un valor.</span><span class="textfieldMinCharsMsg">No se cumple el mínimo de caracteres requerido.</span></span></td>
      <td><img src="spacer.gif" width="1" height="53" border="0" alt="" /></td>
    </tr>
    <tr>
      <td><img name="index_r9_c5" src="index_r9_c5.gif" width="254" height="43" border="0" id="index_r9_c5" alt="" /></td>
      <td><img src="spacer.gif" width="1" height="43" border="0" alt="" /></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><span id="sprytextfield2">
      <label>
        <input type="password" name="password" id="password">
      </label>
      <span class="textfieldRequiredMsg">Se necesita un valor.</span><span class="textfieldMinCharsMsg">No se cumple el mínimo de caracteres requerido.</span></span></td>
      <td><img src="spacer.gif" width="1" height="46" border="0" alt="" /></td>
    </tr>
    <tr>
      <td><img name="index_r11_c5" src="index_r11_c5.gif" width="254" height="36" border="0" id="index_r11_c5" alt="" /></td>
      <td><img src="spacer.gif" width="1" height="36" border="0" alt="" /></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><label>
        <input type="submit" name="enviar" id="enviar" value="Ingresar" />
      </label></td>
      <td><img src="spacer.gif" width="1" height="44" border="0" alt="" /></td>
    </tr>
    <tr>
      <td><img name="index_r13_c5" src="index_r13_c5.gif" width="254" height="68" border="0" id="index_r13_c5" alt="" /></td>
      <td><img src="spacer.gif" width="1" height="68" border="0" alt="" /></td>
    </tr>
    <tr>
      <td colspan="5"><img name="index_r14_c1" src="index_r14_c1.gif" width="800" height="47" border="0" id="index_r14_c1" alt="" /></td>
      <td><img src="spacer.gif" width="1" height="47" border="0" alt="" /></td>
    </tr>
    <tr> </tr>
  </table>
</form>
<table width="800" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>  </tr>
</table>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "none", {validateOn:["blur"], minChars:3});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "none", {validateOn:["blur"], minChars:3});
//-->
</script>
</body>
</html>