<?php require("validar.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0014)about:internet -->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>index_alumno.gif</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--Fireworks CS3 Dreamweaver CS3 target.  Created Tue Sep 21 17:59:48 GMT-0600 2010-->
<script language="JavaScript1.2" type="text/javascript" src="mm_css_menu.js"></script>
<style type="text/css" media="screen">
	@import url("./index_alumno.css");
</style>

</head>
<body bgcolor="#ffffff"><table width="700" border="0" align="center">
  <tr>
    <td><div id="FWTableContainer21604755">
<table border="0" cellpadding="0" cellspacing="0" width="800">
<!-- fwtable fwsrc="indes4.png" fwpage="index_docente" fwbase="index_alumno.gif" fwstyle="Dreamweaver" fwdocid = "21604755" fwnested="0" -->
  <tr>
   <td><img src="spacer.gif" width="15" height="1" border="0" alt="" /></td>
   <td><img src="spacer.gif" width="148" height="1" border="0" alt="" /></td>
   <td><img src="spacer.gif" width="240" height="1" border="0" alt="" /></td>
   <td><img src="spacer.gif" width="277" height="1" border="0" alt="" /></td>
   <td><img src="spacer.gif" width="105" height="1" border="0" alt="" /></td>
   <td><img src="spacer.gif" width="15" height="1" border="0" alt="" /></td>
   <td><img src="spacer.gif" width="1" height="1" border="0" alt="" /></td>
  </tr>

  <tr>
   <td colspan="6"><img name="index_alumno_r1_c1" src="index_alumno_r1_c1.gif" width="800" height="40" border="0" id="index_alumno_r1_c1" alt="" /></td>
   <td><img src="spacer.gif" width="1" height="40" border="0" alt="" /></td>
  </tr>
  <tr>
   <td colspan="3"><img name="index_alumno_r2_c1" src="index_alumno_r2_c1.gif" width="403" height="71" border="0" id="index_alumno_r2_c1" alt="" /></td>
   <td colspan="3"><img name="index_alumno_r2_c4" src="index_alumno_r2_c4.gif" width="397" height="71" border="0" id="index_alumno_r2_c4" alt="" /></td>
   <td><img src="spacer.gif" width="1" height="71" border="0" alt="" /></td>
  </tr>
  <tr>
   <td colspan="2"><a href="principal_institucional.php" onmouseout="MM_menuStartTimeout(1000);" onmouseover="MM_menuShowMenu('MMMenuContainer0908175643_0', 'MMMenu0908175643_0',15,29,'index_alumno_r3_c1');"><img name="index_alumno_r3_c1" src="index_alumno_r3_c1.gif" width="163" height="30" border="0" id="index_alumno_r3_c1" alt="" /></a></td>
   <td colspan="2"><img name="index_alumno_r3_c3" src="index_alumno_r3_c3.gif" width="517" height="30" border="0" id="index_alumno_r3_c3" alt="" /></td>
   <td colspan="2"><a href="cerrar_sesion.php"><img name="index_alumno_r3_c5" src="index_alumno_r3_c5.gif" width="120" height="30" border="0" id="index_alumno_r3_c5" alt="" /></a></td>
   <td><img src="spacer.gif" width="1" height="30" border="0" alt="" /></td>
  </tr>
  <tr>
   <td rowspan="2"><img name="index_alumno_r4_c1" src="index_alumno_r4_c1.gif" width="15" height="405" border="0" id="index_alumno_r4_c1" alt="" /></td>
   <td colspan="4"  bgcolor="#009966"><font color="#FFFFFF" face="Comic Sans MS" size="+1">Usuario en Sesion: <?php echo $_SESSION["nombre_completo"]; ?></font></td>
   <td rowspan="2"><img name="index_alumno_r4_c6" src="index_alumno_r4_c6.gif" width="15" height="405" border="0" id="index_alumno_r4_c6" alt="" /></td>
   <td><img src="spacer.gif" width="1" height="28" border="0" alt="" /></td>
  </tr>
  <tr>
   <td colspan="4" valign="top"><iframe name="fondito" width="770" height="377" frameborder="0" id="fondito"></iframe></td>
   <td><img src="spacer.gif" width="1" height="377" border="0" alt="" /></td>
  </tr>
  <tr>
   <td colspan="6"><img name="index_alumno_r6_c1" src="index_alumno_r6_c1.gif" width="800" height="54" border="0" id="index_alumno_r6_c1" alt="" /></td>
   <td><img src="spacer.gif" width="1" height="54" border="0" alt="" /></td>
  </tr>
</table>
<div id="MMMenuContainer0908175643_0">
	<div id="MMMenu0908175643_0" onmouseout="MM_menuStartTimeout(1000);" onmouseover="MM_menuResetTimeout();">
		<a href="javascript:;" id="MMMenu0908175643_0_Item_0" class="MMMIFVStyleMMMenu0908175643_0" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0','1');">
			<span class="MMMenuItemSpanMMMenu0908175643_0">Notas</span>
			<img src="arrows.gif" alt="" class="MMArrowStyleMMMenu0908175643_0" />
		</a>
	</div>
	<div id="MMMenu0908175643_0_1" onmouseout="MM_menuStartTimeout(1000);" onmouseover="MM_menuResetTimeout();">
		<a href="notas_actuales.php" target="fondito" id="MMMenu0908175643_0_1_Item_0" class="MMMIFVStyleMMMenu0908175643_0_1" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0_1');">
			Ver&nbsp;Notas&nbsp;Actuales
		</a>
		<a href="notas_periodo.php" target="fondito" id="MMMenu0908175643_0_1_Item_1" class="MMMIVStyleMMMenu0908175643_0_1" onmouseover="MM_menuOverMenuItem('MMMenu0908175643_0_1');">
			Ver&nbsp;notas&nbsp;por&nbsp;Periodo
		</a>
	</div>
</div>
</div></td>
  </tr>
</table>
</body>
</html>