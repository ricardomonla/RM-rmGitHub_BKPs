<?php
session_start();
session_destroy();
?>
<script type="text/javascript">
window.onload = window.parent.location.href = "index.php";
</script>

