<?php
include("funciones.php");
nologin();
?>
<h2>Sistema Escolar Version Docentes</h2>
