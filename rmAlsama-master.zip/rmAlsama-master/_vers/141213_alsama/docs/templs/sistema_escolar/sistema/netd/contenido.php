<?php
include("funciones.php");
nologin();
echo "<br><h3>Bienvenido de nuevo, ".$_SESSION['aux_nombre']."</h3>";
?>
