<?php
include("funciones.php");
nologin();
?>
<h1>Sistema Escolar Version Alumnos</h1>
