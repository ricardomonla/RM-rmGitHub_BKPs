/*<®> Inicialización <®>*/
  $.getScript("js/ctrs.js");
  $.getScript("js/jquery.maskedinput.min.js");
  $.getScript("js/md5.js");
  $.getScript("js/mnus.js");
  $.getScript("js/abms.js");
  $.getScript("js/salir.js");
  $.getScript("js/enviar.js");
  $.getScript("js/confirma.js");
  $.getScript("js/login.js");
  
