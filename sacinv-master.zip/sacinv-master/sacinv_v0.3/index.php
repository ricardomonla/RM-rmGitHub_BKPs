<?php 
	include('inventario.php');
?>