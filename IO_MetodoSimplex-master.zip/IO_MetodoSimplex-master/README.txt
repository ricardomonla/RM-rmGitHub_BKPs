Tecnicatura Superior En Programaci�n
UTN Facultad Regional La Rioja
Materia: Investigaci�n Operativa
Tema: Metodo Simplex

El Objetivo de este trabajo es el de dasarrollar un sistema 
que calcule las variables usando el metodo de calculo simplex. 


Tec. MONLA Ricardo
rmonla@gmail.com