<?php
	include_once "../.app.php";
	goDst("gaia.confs");
?>
