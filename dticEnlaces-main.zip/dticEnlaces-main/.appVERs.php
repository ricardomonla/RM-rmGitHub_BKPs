<?php  

/* «® VERSIONADO  ®» */
  $logVERs = " => 
      1.2.4 => CURSOS: Agrega curso LITIO.
      1.2.3 => APP: Re-codificar todos los archivos para iniciar con .app.php
      1.2.2 => APP: Re-codifica archivos para iniciar con .app.php
      1.2.1 => APP: Re-codifica, separa en appDATs y appVERs
      1.1.5 => pi22: Crea el salto
      1.1.4 => gaia.confs: Crea el salto
      1.1.3 => 0623iel: Edita información de los enlaces
      1.1.2 => Crea los saltos INDEX y PPFINAL0623
      1.1.1 => Generación de la función de re-direccionamiento goDst($id='')
      1.0.1 => Inicia codificación del módulo
    ";
  $appVer = explode(" => ", $logVERs);
  $appVer = 'v'.trim($appVer[1]);
    
?>
