<?php
	//  EAMTA22 - AULA VIRTUAL [3] 
	//  6 de Mar 7:00 a 12 Mar 23:00
	//  
	$newURL = 'https://utn.zoom.us/j/81679704114';
	header('Location: '.$newURL);
	die();
?>
