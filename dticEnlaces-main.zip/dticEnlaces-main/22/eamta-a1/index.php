<?php
	//  EAMTA22 - AULA VIRTUAL [1] 
	//  6 de Mar 7:00 a 12 Mar 23:00
	//  
	$newURL = 'https://utn.zoom.us/j/88436434728';
	header('Location: '.$newURL);
	die();
?>
