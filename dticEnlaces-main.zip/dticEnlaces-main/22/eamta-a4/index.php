<?php
	//  EAMTA22 - AULA VIRTUAL [4] 
	//  6 de Mar 7:00 a 12 Mar 23:00
	//  
	$newURL = 'https://utn.zoom.us/j/89548861490';
	header('Location: '.$newURL);
	die();
?>
