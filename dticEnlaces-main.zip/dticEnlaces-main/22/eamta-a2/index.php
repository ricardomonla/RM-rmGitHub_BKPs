<?php
	//  EAMTA22 - AULA VIRTUAL [2] 
	//  6 de Mar 7:00 a 12 Mar 23:00
	//  
	$newURL = 'https://utn.zoom.us/j/81089248182';
	header('Location: '.$newURL);
	die();
?>
