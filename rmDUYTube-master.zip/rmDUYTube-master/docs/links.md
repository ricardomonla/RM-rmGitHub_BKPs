## Links

Aquí puedes encontrar algunos de los links donde hay documentación sobre lo que se utilizó para el desarrollro.

* [GNU Wget 1.18 Manual](https://www.gnu.org/software/wget/manual/wget.html)
* [Linux wget command](https://www.computerhope.com/unix/wget.htm)
* [Wget examples](https://gist.github.com/bueckl/bd0a1e7a30bc8e2eeefd)
* [Curso de Linux 8/60 | Shell Script Básico I](https://www.proyectobyte.com/linux-es/curso-de-linux-860-shell-script-basico-i)
* [UNIX & Linux Shell Scripting Tutorial](http://www.dreamsyssoft.com/unix-shell-scripting/tutorial.php)
* [Shell Scripting Tutorial](https://www.shellscript.sh)
* [aria2c Documentación](https://aria2.github.io/manual/en/html/aria2c.html)