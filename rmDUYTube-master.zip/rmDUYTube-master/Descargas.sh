Descargas

### LAyGIES_Fnzas
screen ./rmDUY \
-a 'LAyGIES_Fnzas_C07_07Oct19_14:00' \
-t 'LAyGIES - Finanzas - C07_07Oct19_14:00' \
-D 'Clase 07 - Luís CARRETERO - Finanzas y Financiamiento en IES - LAyGIES - UTNMendoza' \
-u http://190.114.222.202/tcs/download/EC3EC840-E35C-4CA3-8A0D-5155D391C5E7.mp4

'
_*Última Clase:*_
-->> https://youtu.be/mDHwDmw3HM4
_*Lista de Clases:*_
-->> http://bit.ly/LAyGIES_Fnzas_Clases
'
'
_*Apuntes de Clases:*_
-->> http://bit.ly/LAyGIES_Fnzas_Apuntes
'

### LAyGIES_Epist
screen ./rmDUY \
-a 'LAyGIES_Epist_C08_16Oct19_14:00' \
-t 'LAyGIES - Epistemología - C08_16Oct19_14:00' \
-D 'Clase 08 - Victor OLIVA - Epistemología - LAyGIES - UTNMendoza' \
-u http://190.114.222.202/tcs/download/2CBECA43-006F-4892-A572-0EA4971D1533

'
_*Última Clase:*_
-->> https://youtu.be/_szxmFu5_r4
_*Lista de Clases:*_
-->> http://bit.ly/LAyGIES_Epist_Clases
'
'_*Apuntes de Clases:*_
-->> http://bit.ly/LAyGIES_Epist_Apuntes
'
### LAyGIES_TIC
screen ./rmDUY \
-a 'LAyGIES_TIC08_18Oct19_14:00' \
-t 'LAyGIES - TIC - C08_18Oct19_14:00' \
-D 'Clase 08 - Ing. Anibal CATAPANO GILI - Tecnología de la Información y Comunicaciones en IES - LAyGIES - UTNMendoza' \
-u http://190.114.222.202/tcs/download/EC63B87C-4F36-4CAC-A1F5-EFF8752305F8

'
_*Última Clase:*_
-->> https://youtu.be/kLJR_uSZbYQ
_*Lista de Clases:*_
-->> http://bit.ly/LAyGIES_TIC_Clases
'
# '
# _*Apuntes de Clases:*_
# -->> http://bit.ly/LAyGIES_TIC_Apuntes
# '



### UTNLaRioja_SSAE
screen ./rmDUY \
-a 'SSAE_JDTecnologicos_3Oct19_14:00' \
-t 'UTNLaRioja_SSAE - Juegos Deportivos Tecnológicos - 3Oct19_14:00' \
-D 'Juegos Deportivos Tecnológicos' \
-u http://190.114.222.202/tcs/download/CD8F01FE-BB19-4AAF-A4D5-AE233C60F02D.mp4

'
_*Última Video:*_
-->> https://youtu.be/0L4iT6heX5s
_*Lista de Videos:*_
-->> http://bit.ly/UTNLaRioja_SSAE_VCs
'

### UTNLaRioja_TIC
screen ./rmDUY \
-a 'UTNLaRioja_TIC_ZOOM_26Sept_17:00' \
-t 'UTNLaRioja_TIC - UTN Implementó ZOOM - 26Sept_17:00' \
-D 'UTN Implementó ZOOM, la Plataforma de Comunicación en la Nube - https://utn.edu.ar/es/?option=com_content&view=article&id=537' \
-u http://portalvc.utn.edu.ar:8081/storage-01/2019/videos/2019.09.26-17.00-PRESENTACION_ZOOM-UTN.mp4

'
_*Última V-Conferencia:*_
-->> https://youtu.be/8hWzEkyBEZM
_*Lista de Videos:*_
-->> http://bit.ly/UTNLaRioja_DTIC_VCs
'


