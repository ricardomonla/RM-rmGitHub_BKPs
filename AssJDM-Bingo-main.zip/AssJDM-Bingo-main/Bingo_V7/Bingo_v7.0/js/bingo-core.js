// Lógica central del bingo interactivo
const estadoJuego = {
    bolillas: [],
    historial: [],
    modoAutomatico: false
};
