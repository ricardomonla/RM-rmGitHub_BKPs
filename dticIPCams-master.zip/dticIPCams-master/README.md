# 17_ecptdorFotos

ecptdorFotos.rb                                                           
                          Encarpetador de Fotos                           
                                                                          
Desc:                                                                     
        Script que desde una carpeta lee los archivos de imágenes y       
        las mueve a otro destino ordenado según fecha.                    
                                                                          
Ver:    17.01                                                             
Fecha:  2017-12-11                                                        
Author: Ricardo MONLA rmonla@gmail.com                                    


