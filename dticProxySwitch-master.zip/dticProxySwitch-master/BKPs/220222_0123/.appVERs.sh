#!/bin/bash
clear;


#/* «® VERSIONADO  ®» */


$logVERs = " => 

	v2.6 => FXs: ejecutarRUTEOs() Trabajando....
	v2.5 => FXs: cargaInterface() Optimiza código con parámetro BODY.
	v2.4 => FXs: Crea la función getStrRED() que genera string para cargar en interfaces.
	v2.3 => FXs: Crea la función cargaInterface que genera el archivo de configuración interfaces.conf
	v2.2 => VERs: Genera .appVERs.sh para registro del log de versiones.
	v2.1 => MANU: Genera menú inicial.
	v2.0 => APP: Inicia la reprogramación desde la versión transparent_v1.0.sh.

";


