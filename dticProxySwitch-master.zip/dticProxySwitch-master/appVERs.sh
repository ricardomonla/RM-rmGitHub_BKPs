#!/bin/bash
clear;


#/* «® VERSIONADO  ®» */


$logVERs = " => 

	v2.14 => APP: Agraga y carga la variable SCRIP_DIR.
	v2.13 => FXs: Crea fx aplicarCONFs que aplica las configuraciones generadas.
	v2.12 => FXs: Cambio nombres de fx cargarCFG_IPTABLES y cargarCFG_NETWORK por genrarCFG_XXXX.
	v2.11 => FXs: Crea fx cargarCFG_IPTABLES que genera el archivo de configuración de iptables.
	v2.10 => APP: Optimozo MENU y predetermino opción 9 SALIR.
	v2.9 => APP: Corrige bug /etc/network/interfaces.
	v2.8 => FXs: Agrego salePor8_87.
	v2.7 => APP: Primer puesta en funcionameinto.
	v2.6 => FXs: ejecutarRUTEOs()
	v2.5 => FXs: cargaInterface() Optimiza código con parámetro BODY.
	v2.4 => FXs: Crea la función getStrRED() que genera string para cargar en interfaces.
	v2.3 => FXs: Crea la función cargaInterface que genera el archivo de configuración interfaces.conf
	v2.2 => VERs: Genera .appVERs.sh para registro del log de versiones.
	v2.1 => MANU: Genera menú inicial.
	v2.0 => APP: Inicia la reprogramación desde la versión transparent_v1.0.sh.

";


