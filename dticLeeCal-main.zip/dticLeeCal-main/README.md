# dticLeeCal
Proyecto en python que lee desde un calendario de Google información para procesarla a un archivo de texto de salida. 
