<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Clinica Chango Roto</title>
<style type="text/css">
<!--
.Estilo1 {color: #0033FF}
.Estilo2 {font-weight: bold}
.Estilo3 {font-weight: bold}
.Estilo4 {
	font-weight: bold;
	color: #0033FF;
}
.Estilo6 {font-weight: bold}
.Estilo7 {
	color: #FF0000;
	font-weight: bold;
}
-->
</style>
</head>
<body>
<table width="99%" height="477" border="1" align="center" cellpadding="20">
    <tr>
      <td height="202"><div align="center"><img src="images/001.jpg" width="945" height="160" align="middle" /></div></td>
    </tr>
	<tr>
		<td bgcolor="#99CCFF">
			<form name="baja" action="abm.php" method"post">
				<table width="100%" border="1" cellpadding="20">
  					<tr>
    					<td colspan="2"><div align="center" class="Estilo6 Estilo3 Estilo1"><strong>DATOS PERSONALES </strong></div></td>
   					  <td width="60%" colspan="4"><div align="center" class="Estilo7">DATOS CLINICOS </div></td>
    				</tr>
  					<tr>    					
					<td colspan="2" bgcolor="#CCCCCC" class="Estilo3">
<table width="92%" border="1" cellpadding="20">
  <tr>
    <td colspan="2"><div align="center" class="Estilo1"><strong><span class="Estilo6">INGRESE EL DNI DEL PACIENTES A ELIMINAR </span></strong></div></td>
    </tr>
  <tr>
    <td width="34%"><div align="center" class="Estilo4">DNI:</div></td>
    <td width="66%">      <input name="textfield" type="dni" size="40"/>    </td>
  </tr>
  <tr>
    <td colspan="2" bgcolor="#99CCFF"><span class="Estilo1"></span></td>
    </tr>
  <tr>
    <td><div align="center" class="Estilo1"><strong>APELLIDO:</strong></div></td>
    <td>      <input name="textfield" type="ape" size="40"/>    </td>
  </tr>
  <tr>
    <td><div align="center" class="Estilo1"><strong>NOMBRE:</strong></div></td>
    <td>      <input name="textfield" type="nomb" size="40"/>    </td>
  </tr>
  <tr>
    <td><div align="center" class="Estilo1"><strong>TELEFONO:</strong></div></td>
    <td>      <input name="textfield" type="telef" size="40"/>    </td>
  </tr>
  <tr>
    <td><div align="center" class="Estilo1"><strong>DIRECCION:</strong></div></td>
    <td>      <input name="textfield" type="dire" size="40"/>    </td>
  </tr>
  <tr>
    <td><div align="center" class="Estilo1"><strong>PROVINCIA:</strong></div></td>
    <td>      <input name="textfield" type="prov" size="40"/>    </td>
  </tr>
  <tr>
    <td><div align="center" class="Estilo1"><strong>LOCALIDAD</strong></div></td>
    <td>      <input name="textfield" type="loc" size="40"/>    </td>
  </tr>
  <tr>
    <td><div align="center" class="Estilo1"><strong>MAIL:</strong></div></td>
    <td>      <input name="textfield2" type="mail" size="40"/>    </td>
  </tr>
</table>					</td>
    					<td colspan="4" valign="top" bgcolor="#CCCCCC" class="Estilo2">
							<div align="center" class="Estilo7">
	  					    ALTURA: 
	    					    <input name="alt" type="text" size="10"/>
	  					    PESO: 
	  						    <input name="pes" type="text" size="10" />
						    SEXO: 
	  						    <input name="pes" type="text" size="10" />
	  					    IMC: 
	  						    <input name="imc" type="text" size="10"/>
			                    <br>
	 		                    <br>
	 		                    PRESION --> 
	  					    DIASTOLICA:
                            <input name="pesd" type="text" size="10"/>
	  					    SISTOLICA: 
	  						    <input name="pess" type="text" size="10"/>
			                    <br>
			                    <br>
	  					    OBRA SOCIAL: 
	  						    <input name="obsc" type="text" size="20"/>
	  					    PARTICULAR: 
	  						     <input name="part" type="text" size="30"/>
	  						     <br>
	  						     <br>
  						        N&ordm; OBRA SOCIAL:
                                 <input name="nobs" type="text" size="10"/>
                                N&ordm; HISTORIA CLINICA:
                                 <input name="nhc" type="text" size="10"/>
                                 <br>
                                 <br>
						    MOTIVO DE CONSULTA: 
	  						     <input name="nobs" type="text" size="30"/>
	  						     <br>
	  						     <br>
	  					    INSUMOS UTILIZADOS:<br>
	  					    <textarea name="insum" cols="90" rows="10"></textarea>
	  					    <br>
	  					    <br>			  					
                            <br>
       					    </div>						 </td>
    				</tr>
			  </table>
					<div align="center">
					 <br>
					  <input name="enviar" type="submit" class="Estilo2" value="ENVIAR"/>
			         <br>
			  </div>
			</form>		
	  </td>
	</tr>
</table>
</body>
</html>
