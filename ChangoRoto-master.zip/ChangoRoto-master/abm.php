<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Clinica Chango Roto</title>
<style type="text/css">
<!--
.Estilo1 {
	color: #FF0000;
	font-weight: bold;
}
.Estilo2 {color: #FF0000; font-weight: bold; font-size: 18px; }
.Estilo3 {color: #009900; font-weight: bold; font-size: 18px; }
.Estilo5 {
	color: #FFFF00;
	font-size: 18px;
}
.Estilo6 {color: #FF0033; font-weight: bold; }
-->
</style>
</head>
<body>
<div align="center">
  <table width="80%" border="1" align="center" cellpadding="20">
    <tr>
      <td colspan="3"><img src="images/001.jpg" width="945" height="160" align="middle" /></td>
    </tr>
	<tr>
      <td width="23%" height="415"><img src="images/Arte publicitario Aspirina.jpg" width="206" height="339" /></td>
	  <td width="53%">
	  	<form name="abm" action="index.php" method="post">
			<div align="center">
			  <table width="100%" border="1" cellpadding="20">
			    <tr>
			      <td width="79%" bgcolor="#3399FF"><div align="center" class="Estilo3">ALTA DE PACIENTES </div></td>
			      <td width="21%" bgcolor="#3399FF"><a href="alta.php"><img src="images/mas2.jpg" alt="" width="60" height="60" /></a></td>
			    </tr>
			    <tr>
			      <td class="Estilo2" bgcolor="#3399FF"><div align="center" class="Estilo6">BAJA DE PACIENTES </div></td>
			      <td bgcolor="#3399FF"><a href="baja.php"><img src="images/menos2.jpg" width="60" height="60" /></a></td>
			    </tr>
			    <tr>
			      <td height="106" bgcolor="#3399FF" class="Estilo1"><div align="center" class="Estilo1 Estilo5">MODIFICACION DE PACIENTES </div></td>
			      <td bgcolor="#3399FF"><a href="modif.php"><img src="images/mod.jpg" width="60" height="60" /></a></td>
			    </tr>
              </table>
			  <br>
			  <input type="submit" class="Estilo2" value="Salir" />
		  </div>
  	  </form>
	  <td width="24%"><img src="images/lr.jpg" width="200" height="177" />
	  <img src="images/apos.jpg" width="200" height="177" />
	  </td>
    </tr>
 </table>
</div>
</body>
</html>
